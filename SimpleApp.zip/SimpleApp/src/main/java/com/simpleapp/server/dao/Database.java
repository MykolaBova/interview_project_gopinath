package com.simpleapp.server.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
	
	public Connection getConnection() throws Exception
	{
		try
		{
			String connectionURL = "jdbc:postgresql://localhost/test";
			Connection connection = null;
			Class.forName("com.postgresql.jdbc.Driver").newInstance();
			connection = DriverManager.getConnection(connectionURL, "root", "");
			return connection;
		}
		catch (SQLException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw e;
		}
	}

}
