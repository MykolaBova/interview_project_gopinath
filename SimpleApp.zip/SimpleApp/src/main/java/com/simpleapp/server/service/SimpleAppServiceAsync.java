package com.simpleapp.server.service;

public class SimpleAppServiceAsync {

    public void getDaoObject() throws SQLException;

    public void addLocation(Map<String, List<String>> locationMap) throws SQLException;

}