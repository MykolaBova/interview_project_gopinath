package com.simpleapp.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.RootPanel;

import java.awt.ItemSelectable;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.ComboBoxItem;

public class SimpleAppClient implements EntryPoint {

    /**
     * Create a remote service proxy to talk to the server-side simple app service.
     */
    private final SimpleAppServiceAsync simpleAppService = GWT.create(SimpleAppService.class);

    public void onModuleLoad() {
        LocationClient client = GWT.create(LocationClient.class);

        client.getLocations(new MethodCallback<List<Hello>>() {

            public void onSuccess(Method method, List<Map<String, List<String>>> response) {
                Map<String, List<String>> locationsMap = null;
                VerticalPanel panel = new VerticalPanel();
                for (Map<String, List<String>> locationMap : response) {
                    RootPanel.get().add(getViewPanel(locationMap));
                }
            }

            public void onFailure(Method method, Throwable exception) {
                Label label = new Label("Error");
                RootLayoutPanel.get().add(label);
            }
        });
    }

    public Canvas getViewPanel(Map<String, List<String>> locationMap) {
        DynamicForm form = new DynamicForm();

        ComboBoxItem cbItem = new ComboBoxItem();
        cbItem.setTitle("Select");
        cbItem.setHint("<nobr>A simple combobox</nobr>");
        cbItem.setType("comboBox");
        cbItem.setValueMap(locationMap);

        ItemListener itemListener = new ItemListener() {
            public void itemStateChanged(ItemEvent itemEvent) {
                int state = itemEvent.getStateChange();
                System.out.println((state == ItemEvent.SELECTED) ? "Selected" : "Deselected");
                System.out.println("Item: " + itemEvent.getItem());
                ItemSelectable is = itemEvent.getItemSelectable();
                System.out.println(", Selected: " + selectedString(is));
                insertToPostgreSQL(locationMap);
            }
        };
        cbItem.addItemListener(itemListener);

        form.setFields(cbItem);

        return form;

    }

    private void insertToPostgreSQL(Map<String, List<String>> locationMap) {

        simpleappService.addLocation(locationMap
                new AsyncCallback() {
                    public void onFailure(Throwable caught) {
                        // Show the RPC error message to the user
                        RootPanel.get().add(new HTML(“RPC call failed. :-(“));
                    }
                    public void onSuccess(String result) {
                        RootPanel.get().add(new HTML(“RPC call Success:”));
                    }
                });
    }

