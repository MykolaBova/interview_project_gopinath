package com.simpleapp.server.service;

import com.google.inject.Inject;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class SimpleAppServiceImpl extends RemoteServiceServlet implements SimpleAppService {

    @Inject
    private SimpleAppDao simpleAppDao;

    public void getDaoObject() {
        //Get DAO objects using GWT Guice
    }

    public void addLocation(Map<String, List<String>> locationMap) {
        //Write code to invoke methods (add location) in DAO layer & send the location map
    }

}