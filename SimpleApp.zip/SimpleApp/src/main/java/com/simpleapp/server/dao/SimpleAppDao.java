package com.simpleapp.server.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SimpleAppDao {

    private static final String PERSISTENCE_UNIT_NAME = "User";
    private static EntityManagerFactory factory;

    public Location addLocation(Map<String, List<String>> locationMap) {
        factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = factory.createEntityManager();
        // Read the existing entries and write to console
        Query q = em.createQuery("insert into location (citynames,places) values(?,?)");
        List<Location> locationList = q.getResultList();

        System.out.println("Size: " + locationList.size());

        for (Map.Entry<String, List<String>> location : locationMap.entrySet()) {
            // Create new location
            em.getTransaction().begin();
            Location location = new Location();
            location.setCityname(location.getKey());
            location.setPlaces(location.getValue());
            em.persist(location);
            em.getTransaction().commit();
            break;
        }
        em.close();
    }

}