package com.simpleapp.server.webService;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/* Get all the places by consuming this web service */
@Path("/WebService")
public class LocationService {
	
	@GET
	@Path("/GetPlaces")
	@Produces("application/json")
	public List<String> getLocations()
	{
		String places  = null;

		Map<String, List<String>> locationMap = new HashMap<String, List<String>>();
		List<Map<String, List<String>>> allLocationList = new ArrayList<Map<String, List<String>>>();
		try
		{
			/* Need to write actual logic to populate the list by doing a search with let’s’ say 5km radius using below
			https://developers.google.com/places/web-service/search */

			List<String> placeList1 = new ArrayList<String>();
			placeList1.add("Albany");
			placeList1.add("Malta");
			placeList1.add("Clifton Park");
			locationMap.put("New York", placeList1);

			List<String> placeList2 = new ArrayList<String>();
			placeList2.add("Chicago");
			placeList2.add("Prospect Heights");
			placeList2.add("Wheeling");
			locationMap.put("Illinois", placeList2);

			allLocationList.add(locationMap);

			if (placeList1 != null && placeList1.size() > 0) {
				placeList1.clear();
			}

			if (placeList2 != null && placeList2.size() > 0) {
				placeList2.clear();
			}

		} catch (Exception e)
		{
			System.out.println("error");
		}
		return feeds;
	}



}
