package com.simpleapp.server.service;

public class SimpleAppService {

    void getDaoObject() throws SQLException;

    void addLocation(Map<String, List<String>> locationMap) throws SQLException;

}